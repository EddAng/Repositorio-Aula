Trabalho de Desenvolvimento Web, 1 semestre. Univille.

  Projeto Simulação de uma estrutura de Registro de Finanças;
  Nome dado ao projeto: Imbibcs.
  Focamos em utilizar, majoritariamente, HTML na estrutura e um visual limpo.

Por: Luiz Felipe e Eduardo Angeli;
  Sistemas da informação, Engenharia de Software
